import DrawerMenu from '@components/DrawerMenu';

// import styles from './MyAnnouncementsPage.module.css';

const MyAnnouncementsPage = () => {
  return (
    <>
      <h1>MyAnnouncementsPage</h1>
      <DrawerMenu />
    </>
  );
};

export default MyAnnouncementsPage;
