import DrawerMenu from '@components/DrawerMenu';

// import styles from './SettingsPage.module.css';

const SettingsPage = () => {
  return (
    <>
      <h1>SettingsPage</h1>
      <DrawerMenu />
    </>
  );
};

export default SettingsPage;
