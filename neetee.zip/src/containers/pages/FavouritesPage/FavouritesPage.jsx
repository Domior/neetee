import DrawerMenu from '@components/DrawerMenu';

// import styles from './FavouritesPage.module.css';

const FavouritesPage = () => {
  return (
    <>
      <h1>FavouritesPage</h1>
      <DrawerMenu />
    </>
  );
};

export default FavouritesPage;
