export { default } from './FavouritesPage';
