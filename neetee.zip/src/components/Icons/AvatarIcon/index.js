export { default } from './AvatarIcon';
