export { default } from './HomeIcon';
