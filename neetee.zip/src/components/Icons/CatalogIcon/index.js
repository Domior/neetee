export { default } from './CatalogIcon';
